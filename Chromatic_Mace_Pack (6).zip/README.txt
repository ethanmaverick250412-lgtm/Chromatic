CHROMAMACE - resource pack (Minecraft Java 1.21.9+ / 26.x)

The mace changes look based on its custom_model_data value (1-8).
No value = vanilla mace.

TIERS (each one has a different shape):
  1. Crimson   - spiked ball
  2. Ember     - flanged blades
  3. Citrine   - crystal starburst + crossguard
  4. Verdant   - flanged head + feathered wings
  5. Aqua      - crystal head + orbit ring
  6. Sapphire  - crystal cross + ring + floating shards
  7. Amethyst  - crown + wings + ring + sparkles
  8. Prismatic - animated rainbow, everything combined

TEST: /give @s mace[custom_model_data={floats:[3]}]

3D: in hand, on the ground and in item frames the mace is a full 3D model.
The inventory/hotbar icon stays the flat pixel-art sprite.
